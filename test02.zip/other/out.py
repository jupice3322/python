def plus():
    print("더하기 기능 처리")
    number1 = int(input("숫자1 입력: "))
    number2 = int(input("숫자2 입력: "))
    sum = number1 + number2
    print("결과는", sum)


def minus():
    print("빼기 기능 처리")
    number1 = int(input("숫자1 입력: "))
    number2 = int(input("숫자2 입력: "))
    sum = number1 - number2
    print("결과는", sum)


def mul():
    print("곱하기 기능 처리")
    number1 = int(input("숫자1 입력: "))
    number2 = int(input("숫자2 입력: "))
    sum = number1 * number2
    print("결과는", sum)
