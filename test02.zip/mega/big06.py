num1=33
num2=4

print("나누기(총값)=",num1/num2)
print("나누기(몫)=",num1//num2)
print("나누기(나머지)=",num1%num2)