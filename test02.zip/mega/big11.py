from other import out

out.plus()
