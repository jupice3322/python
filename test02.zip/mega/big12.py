# big12.py
from movie import price

price.pay()
